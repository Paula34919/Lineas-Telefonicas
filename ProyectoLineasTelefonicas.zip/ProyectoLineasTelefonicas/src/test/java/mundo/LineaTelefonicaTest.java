/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author julyj
 */
public class LineaTelefonicaTest {
    
    private LineaTelefonica linea;
    
    public void iniciarEscenario1(){
        linea = new LineaTelefonica( );
        linea.inicializar( );
    }
    
    @Test
    public void testAgregarLlamadaCelular(){
        iniciarEscenario1();
        linea.agregarLlamadaCelular( 50 ); //CostoCelular = 800.8 / min
        assertEquals(1, linea.darNumeroLlamadas(), "El número de llamadas debe ser 1" );
        assertEquals( 50, linea.darNumeroMinutos(), "El número de minutos debe ser 10" );
        assertEquals( 40040, linea.darCostoLlamadas(), "El costo debe ser $40040" );
    }
    
    @Test
    public void testAgregarLlamadaLocal() {
        iniciarEscenario1();
        linea.agregarLlamadaLocal( 15 ); //CostoLocal = 200.5 / min
        assertEquals( 1, linea.darNumeroLlamadas(), "El número de llamadas debe ser 1" );
        assertEquals( 15, linea.darNumeroMinutos(), "El número de minutos debe ser 15" );
        assertEquals( 3007.5, linea.darCostoLlamadas(), "El costo debe ser $3007.5" );
    }
    
    @Test
    public void testAgregarLlamadaLargaDistancia() {
        iniciarEscenario1();
        linea.agregarLlamadaLargaDistancia( 2 ); //CostoLargaDistancia = 1500.2 / min
        assertEquals( 1, linea.darNumeroLlamadas(), "El número de llamadas debe ser 1" );
        assertEquals( 2, linea.darNumeroMinutos(), "El número de minutos debe ser 2" );
        assertEquals( 3000.4, linea.darCostoLlamadas(), "El costo debe ser $3000. 4" );
    }
    
    @Test
    public void Reiniciar() {
        iniciarEscenario1();
        linea.agregarLlamadaLocal( 15 );
        linea.agregarLlamadaLargaDistancia( 2 );
        linea.reiniciar();
        assertEquals( 0, linea.darNumeroLlamadas(), "El número de llamadas debe ser 0" );
        assertEquals( 0, linea.darNumeroMinutos(), "El número de minutos debe ser 0" );
        assertEquals( 0, linea.darCostoLlamadas(), "El costo debe ser $0" );
    }

    }
    

