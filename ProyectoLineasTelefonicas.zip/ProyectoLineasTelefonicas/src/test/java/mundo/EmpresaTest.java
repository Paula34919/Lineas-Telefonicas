/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author julyj
 */
public class EmpresaTest {
    
    private Empresa empresa;
    
    public void setupEscenario1() {
        empresa = new Empresa( );
        empresa.inicializar( );
    }

    public void setupEscenario2() {
        empresa = new Empresa( );
        empresa.inicializar( );

        empresa.agregarLlamadaLocalLinea1( 5 );
        empresa.agregarLlamadaLargaDistanciaLinea1( 6 );

        empresa.agregarLlamadaLargaDistanciaLinea2( 6 );
        empresa.agregarLlamadaCelularLinea2( 7 );

        empresa.agregarLlamadaLocalLinea2( 5 );
        empresa.agregarLlamadaCelularLinea2( 7 );
    }
    
    @Test
    public void testInicializar() {
        System.out.println("inicializar");
        Empresa instance = new Empresa();
        instance.inicializar();
    }
    
    @Test    
    public void testinicializacion() {
        setupEscenario1( );
        assertNotNull(empresa.darLinea1( ), "Línea 1 tiene que estar inicializada" );
        assertNotNull(empresa.darLinea2( ), "Línea 2 tiene que estar inicializada" );
        assertNotNull(empresa.darLinea3( ), "Línea 3 tiene que estar inicializada" );
    }
    
    @Test
    public void testAgregarLlamadaLocalLinea1() {
        setupEscenario1( );
        empresa.agregarLlamadaLocalLinea1( 1 );
        assertEquals( 1, empresa.darLinea1( ).darNumeroLlamadas( ) );
    }
    
    @Test
    public void testAgregarLlamadaLocalLinea2() {
        setupEscenario1( );
        empresa.agregarLlamadaLocalLinea2( 1 );
        assertEquals( 1, empresa.darLinea2( ).darNumeroLlamadas( ) );
    }
    
    @Test
    public void testAgregarLlamadaLocalLinea3() {
        setupEscenario1( );
        empresa.agregarLlamadaLocalLinea3( 1 );
        assertEquals( 1, empresa.darLinea3( ).darNumeroLlamadas( ) );
    }
    
    @Test
    public void testAgregarLlamadaLargaDistanciaLinea1(){
        setupEscenario1( );
        empresa.agregarLlamadaLargaDistanciaLinea1( 1 );
        assertEquals( 1, empresa.darLinea1( ).darNumeroLlamadas( ) );
    }
    
    @Test
    public void testAgregarLlamadaLargaDistanciaLinea2(){
        setupEscenario1( );
        empresa.agregarLlamadaLargaDistanciaLinea2( 1 );
        assertEquals( 1, empresa.darLinea2( ).darNumeroLlamadas( ) );
    }
    
    @Test
    public void testAgregarLlamadaLargaDistanciaLinea3(){
        setupEscenario1( );
        empresa.agregarLlamadaLargaDistanciaLinea3( 1 );
        assertEquals( 1, empresa.darLinea3( ).darNumeroLlamadas( ) );
    }
    
    @Test
    public void testAgregarCelularDistanciaLinea1() {
        setupEscenario1( );
        empresa.agregarLlamadaCelularLinea1( 1 );
        assertEquals( 1, empresa.darLinea1( ).darNumeroLlamadas( ) );
    }
    
    @Test
    public void testAgregarCelularDistanciaLinea2() {
        setupEscenario1( );
        empresa.agregarLlamadaCelularLinea2( 1 );
        assertEquals( 1, empresa.darLinea2( ).darNumeroLlamadas( ) );
    }

    @Test
    public void testAgregarCelularDistanciaLinea3() {
        setupEscenario1( );
        empresa.agregarLlamadaCelularLinea3( 1 );
        assertEquals( 1, empresa.darLinea3( ).darNumeroLlamadas( ) );
    }

    @Test
    public void testDarTotalLlamadas() {
        setupEscenario2( );
        assertEquals( 6, empresa.darTotalNumeroLlamadas( ) );
    }

    @Test
    public void testDarTotalMinutos() {
        setupEscenario2( );
        assertEquals( 36, empresa.darTotalMinutos( ) );
    }
    
    @Test
    public void testDarTotalCosto() {
        setupEscenario2( ); // CostoCelular = 800.8 / min ; CostoLocal = 200.5 / min ; CostoLargaDistancia = 1500.2 / min
        assertEquals( 31218.6, empresa.darTotalCostoLlamadas( ));
    }
    
    @Test
    public void testDarCostoPromedio() {
        setupEscenario2( );
        DecimalFormat formatoReducido = new DecimalFormat("#.###");
        
        assertEquals( "867,183" , formatoReducido.format(empresa.darCostoPromedioMinuto( )) );
    }
    
    @Test
    public void testReiniciar() {
        setupEscenario2( );
        empresa.reiniciar( ); 
        assertEquals( 0, empresa.darTotalNumeroLlamadas( ) );
        assertEquals( 0, empresa.darTotalMinutos( ) );
        assertEquals( 0, empresa.darTotalCostoLlamadas( ) );
    }

    

    
}
