/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

public class Empresa {

    private LineaTelefonica linea1;
    private LineaTelefonica linea2;
    private LineaTelefonica linea3;

    public void inicializar() {
        linea1 =  new LineaTelefonica();
        linea2 = new LineaTelefonica();
        linea3 =  new LineaTelefonica();
    }

    public LineaTelefonica darLinea1( )
    {
        return linea1;
    }
    public LineaTelefonica darLinea2( )
    {
        return linea2;
    }
    public LineaTelefonica darLinea3( )
    {
        return linea3;
    }

    public void agregarLlamadaLocalLinea1(int minutos) {
        linea1.agregarLlamadaLocal(minutos);
    }

    public void agregarLlamadaLocalLinea2(int minutos) {
        linea2.agregarLlamadaLocal(minutos);
    }

    public void agregarLlamadaLocalLinea3(int minutos) {
        linea3.agregarLlamadaLocal(minutos);
    }

    public void agregarLlamadaLargaDistanciaLinea1(int minutos) {
        linea1.agregarLlamadaLargaDistancia(minutos);
    }

    public void agregarLlamadaLargaDistanciaLinea2(int minutos) {
        linea2.agregarLlamadaLargaDistancia(minutos);
    }

    public void agregarLlamadaLargaDistanciaLinea3(int minutos) {
        linea3.agregarLlamadaLargaDistancia(minutos);
    }

    public void agregarLlamadaCelularLinea1(int minutos) {
        linea1.agregarLlamadaCelular(minutos);
    }

    public void agregarLlamadaCelularLinea2(int minutos) {
        linea2.agregarLlamadaCelular(minutos);
    }   

    public void agregarLlamadaCelularLinea3(int minutos) {
        linea3.agregarLlamadaCelular(minutos);
    }

    public int darTotalNumeroLlamadas() {
        return linea1.darNumeroLlamadas() +
        linea2.darNumeroLlamadas() +
        linea3.darNumeroLlamadas();
    }

    public int darTotalMinutos() {
        return linea1.darNumeroMinutos() +
        linea2.darNumeroMinutos() +
        linea3.darNumeroMinutos();
    }

    public double darTotalCostoLlamadas() {
        return linea1.darCostoLlamadas() +
        linea2.darCostoLlamadas() +
        linea3.darCostoLlamadas();
    }
    public double darCostoPromedioMinuto(){
        return darTotalCostoLlamadas()/darTotalMinutos();
    }

    public void reiniciar() {
        linea1.reiniciar();
        linea2.reiniciar();
        linea3.reiniciar();
    }

}
