/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

public class LineaTelefonica {
    private int numeroLlamadas;
    private int numeroMinutos;
    private double costoLlamadas;

    public void inicializar() {
        numeroLlamadas = 0;
        numeroMinutos = 0;
        costoLlamadas = 0.0;
    }

    public void reiniciar() {
        inicializar();
    }

    public double darCostoLlamadas() {
        return costoLlamadas;
    }

    public int darNumeroLlamadas(){
        return numeroLlamadas;
    }

    public int darNumeroMinutos() {
        return numeroMinutos;
    }

    public void agregarLlamadaLocal(int minutos){
        numeroLlamadas++;
        numeroMinutos += minutos;
        costoLlamadas += minutos * 200.5;
    }

    public void agregarLlamadaLargaDistancia(int minutos) {
        numeroLlamadas++;
        numeroMinutos += minutos;
        costoLlamadas += minutos * 1500.2;
    }

    public void agregarLlamadaCelular(int minutos) {
        numeroLlamadas++;
        numeroMinutos += minutos;
        costoLlamadas += minutos * 800.8;
    }
}

