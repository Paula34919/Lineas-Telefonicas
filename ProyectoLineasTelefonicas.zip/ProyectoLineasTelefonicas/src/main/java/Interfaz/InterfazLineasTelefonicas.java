/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import mundo.Empresa;

/**
 *
 * @author julyj
 */
public class InterfazLineasTelefonicas extends JFrame {
    
    //Atributos
    private PanelLineaTelefonica panelLinea1, panelLinea2, panelLinea3;
    private PanelTotales panelTotales;
    private PanelImagen panelImagen;
    private PanelExtension panelExtension;
    private PanelIntroduccion panelIntro; 
    private Empresa empresa;

    public InterfazLineasTelefonicas(){
        
        empresa = new Empresa();
        empresa.inicializar();
        
        setSize(1200, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Manejo Líneas Telefonicas");
        setLayout(new BorderLayout());
        setResizable(false);
        
        //Instanciación de los paneles contenedores
        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(new BorderLayout());
        add(panelSuperior, BorderLayout.NORTH);
        
        JPanel panelContenedor = new JPanel();
        panelContenedor.setLayout( new GridLayout(1, 2));
        add(panelContenedor, BorderLayout.CENTER);
        
        JPanel panelLineas = new JPanel();
        panelLineas.setLayout(null);
        panelContenedor.add(panelLineas);        
        
        // Instanciación y agregación de paneles principales
        panelIntro = new PanelIntroduccion(this); 
        panelLineas.add(panelIntro); 
        
        panelLinea1 = new PanelLineaTelefonica(1, this);        
        panelLineas.add(panelLinea1);
        
        panelLinea2 = new PanelLineaTelefonica(2, this);        
        panelLineas.add(panelLinea2);
        
        panelLinea3 = new PanelLineaTelefonica(3, this);        
        panelLineas.add(panelLinea3);
        
        panelTotales = new PanelTotales();
        panelSuperior.add(panelTotales, BorderLayout.CENTER);
        
        panelImagen = new PanelImagen();
        panelSuperior.add(panelImagen, BorderLayout.WEST);
        
        panelExtension = new PanelExtension(this);
        panelContenedor.add(panelExtension);
    }
 
    private void actualizar() {
        panelTotales.actualizar( empresa );
        panelLinea1.actualizar( empresa.darLinea1( ) );
        panelLinea2.actualizar( empresa.darLinea2( ) );
        panelLinea3.actualizar( empresa.darLinea3( ) );
    }
    
    public void reiniciar(){
        empresa.reiniciar();
        actualizar();
    }
    
    public void agregarLlamada( int numeroLinea )
    {
        //
        //Pregunta el numero de minutos
        String minutos = JOptionPane.showInputDialog( this, "Número de Minutos hablados:" );
        try
        {
            if( minutos != null )
            {
                int min = Integer.parseInt( minutos );
                if( min <= 0 )
                {
                    JOptionPane.showMessageDialog( this, "El número de minutos debe ser mayor a cero", "Error", JOptionPane.ERROR_MESSAGE );
                    return;
                }
                Object[] possibilities = { "Local", "Larga distancia", "Celular" };
                String tipo = ( String )JOptionPane.showInputDialog( this, "Tipo de llamada:", "Tipo", JOptionPane.QUESTION_MESSAGE, null, possibilities, "Local" );
                if( tipo != null )
                {
                    switch (numeroLinea) {
                        case 1:
                        switch (tipo) {
                            case "Local":
                                empresa.agregarLlamadaLocalLinea1( min );
                                break;
                            case "Larga distancia":
                                empresa.agregarLlamadaLargaDistanciaLinea1( min );
                                break;
                            case "Celular":
                                empresa.agregarLlamadaCelularLinea1( min );
                                break;
                            default:
                                break;
                        }
                        break;

                        case 2:
                        switch (tipo) {
                            case "Local":
                                empresa.agregarLlamadaLocalLinea2( min );
                                break;
                            case "Larga distancia":
                                empresa.agregarLlamadaLargaDistanciaLinea2( min );
                                break;
                            case "Celular":
                                empresa.agregarLlamadaCelularLinea2( min );
                                break;
                            default:
                                break;
                        }   
                        break;

                        case 3:
                        switch (tipo) {
                            case "Local":
                                empresa.agregarLlamadaLocalLinea3( min );
                                break;
                            case "Larga distancia":
                                empresa.agregarLlamadaLargaDistanciaLinea3( min );
                                break;
                            case "Celular":
                                empresa.agregarLlamadaCelularLinea3( min );
                                break;
                            default:
                                break;
                        }
                        break;

                        default:
                            break;
                    }
                    actualizar( );
                }
            }
        }
        catch( NumberFormatException e )
        {
            JOptionPane.showMessageDialog( this, "El número de minutos es inválido", "Error", JOptionPane.ERROR_MESSAGE );
        }
    }
    
    public void cambiarPanel(int numeroPanel) {
        
        panelExtension.setVisible(true);
        panelIntro.setVisible(false);
        
        switch (numeroPanel) {
            case 1:
                panelLinea1.setVisible(true);
                panelLinea2.setVisible(false);
                panelLinea3.setVisible(false);
                break;
            case 2:
                panelLinea1.setVisible(false);
                panelLinea2.setVisible(true);
                panelLinea3.setVisible(false);
                break;
            case 3:
                panelLinea1.setVisible(false);
                panelLinea2.setVisible(false);
                panelLinea3.setVisible(true);
                break;
            default:
                break;
        }
    }
    
    public static void main(String[] args) {
        InterfazLineasTelefonicas principal = new InterfazLineasTelefonicas();
        principal.setVisible(true);
    }

    public void cambioModoEnteros() {
        panelTotales.modoEnteros( empresa );
        panelLinea1.modoEnteros( empresa.darLinea1( ) );
        panelLinea2.modoEnteros( empresa.darLinea2( ) );
        panelLinea3.modoEnteros( empresa.darLinea3( ) );
    }
    
    public void cambioModoDecimales() {
        panelTotales.actualizar( empresa );
        panelLinea1.actualizar( empresa.darLinea1( ) );
        panelLinea2.actualizar( empresa.darLinea2( ) );
        panelLinea3.actualizar( empresa.darLinea3( ) );
    }


    



}
