/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author julyj
 */
public class PanelIntroduccion extends JPanel implements ActionListener {
    
    //Atributos
    private static final String PANEL1 = "PANEL1";
    private static final String PANEL2 = "PANEL2";
    private static final String PANEL3 = "PANEL3";
    private InterfazLineasTelefonicas principal;
    
    public PanelIntroduccion(InterfazLineasTelefonicas interfaz){
        
        this.principal = interfaz;
        setLayout( new GridLayout(4, 1));
        setBounds(0, 0, 600, 300);
        setVisible(true);
        
        //Construimos los componentes del panel intro        
        JLabel etiquetaIntro = new JLabel();
        etiquetaIntro.setText("Escoja una línea telefónica");
        etiquetaIntro.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaIntro.setOpaque(true); //Establecemos pintar el fondo de la etiqueta
        etiquetaIntro.setBackground(Color.cyan); //Cambiamos el color del fondo de la etiqueta
        add(etiquetaIntro);
        
        //Comando de cambio de paneles
        JButton btnPanel1 = new JButton( "Linea No.1 ");
        btnPanel1.setPreferredSize( new Dimension(150, 25));
        btnPanel1.setActionCommand( PANEL1 );
        btnPanel1.addActionListener(this);
        add(btnPanel1);
        
        JButton btnPanel2 = new JButton( "Linea No.2 ");
        btnPanel2.setPreferredSize( new Dimension(150, 25));
        btnPanel2.setActionCommand( PANEL2 );
        btnPanel2.addActionListener(this);
        add(btnPanel2);
        
        JButton btnPanel3 = new JButton( "Linea No.3 ");
        btnPanel3.setPreferredSize( new Dimension(150, 25));
        btnPanel3.setActionCommand( PANEL3 );
        btnPanel3.addActionListener(this);
        add(btnPanel3);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (null != e.getActionCommand())switch (e.getActionCommand()) {
            case PANEL1:
                principal.cambiarPanel(1);
                break;
            case PANEL2:
                principal.cambiarPanel(2);
                break;
            case PANEL3:
                principal.cambiarPanel(3);
        
                break;
            default:
                break;
        }
    }
}
