/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author julyj
 */
public class PanelExtension extends JPanel implements ActionListener{
    
    //Botones
    private static final String REINICIAR = "REINICIAR";
    private static final String MODOENTEROS = "MODO ENTEROS";
    private static final String MODODECIMALES = "MODO DECIMALES";
    private static final String PANEL1 = "PANEL1";
    private static final String PANEL2 = "PANEL2";
    private static final String PANEL3 = "PANEL3";
    private JButton btnReiniciar, btnMostrarPanel1, btnMostrarPanel2, btnMostrarPanel3, btnModoEnteros, btnModoDecimales;
    private InterfazLineasTelefonicas principal;
   
    public PanelExtension(InterfazLineasTelefonicas elPadre){
        this.principal = elPadre;
        setLayout( new GridLayout(3,3));
        setVisible(false);
        
        //Construir botones                    
        btnMostrarPanel1 = new JButton( "Cambiar a Linea 1 ");
        btnMostrarPanel1.setPreferredSize( new Dimension(150, 25));
        btnMostrarPanel1.setActionCommand( PANEL1 );
        btnMostrarPanel1.addActionListener(this);
        add(btnMostrarPanel1);
        
        btnModoDecimales = new JButton( "Modo Decimales");
        btnModoDecimales.setPreferredSize( new Dimension(150, 25));
        btnModoDecimales.setActionCommand( MODODECIMALES );
        btnModoDecimales.addActionListener(this);
        add(btnModoDecimales);
        
        btnMostrarPanel2 = new JButton( "Cambiar a Linea 2 ");
        btnMostrarPanel2.setPreferredSize( new Dimension(150, 25));
        btnMostrarPanel2.setActionCommand( PANEL2 );
        btnMostrarPanel2.addActionListener(this);
        add(btnMostrarPanel2);
        
        btnModoEnteros = new JButton( "Modo Enteros");
        btnModoEnteros.setPreferredSize( new Dimension(150, 25));
        btnModoEnteros.setActionCommand( MODOENTEROS );
        btnModoEnteros.addActionListener(this);
        add(btnModoEnteros);
        
        btnMostrarPanel3 = new JButton( "Cambiar a Linea 3 ");
        btnMostrarPanel3.setPreferredSize( new Dimension(150, 25));
        btnMostrarPanel3.setActionCommand( PANEL3 );
        btnMostrarPanel3.addActionListener(this);
        add(btnMostrarPanel3);
               
        btnReiniciar = new JButton( "Reiniciar");
        btnReiniciar.setPreferredSize( new Dimension(150, 25));
        btnReiniciar.setActionCommand( REINICIAR );
        btnReiniciar.addActionListener(this);
        add(btnReiniciar);
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
            if (null != e.getActionCommand())switch (e.getActionCommand()) {
            case PANEL1:
                principal.cambiarPanel(1);
                break;
            case PANEL2:
                principal.cambiarPanel(2);
                break;
            case PANEL3:
                principal.cambiarPanel(3);
                break;
            case MODOENTEROS:
                principal.cambioModoEnteros();
                break;
            case MODODECIMALES:
                principal.cambioModoDecimales();
                break;                    
            case REINICIAR:
                principal.reiniciar();
                break;
            default:
                break;
        }
    }
        
    
    
}
