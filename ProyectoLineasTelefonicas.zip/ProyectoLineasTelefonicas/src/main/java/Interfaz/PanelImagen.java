/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import java.awt.Color;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

/**
 *
 * @author julyj
 */
public class PanelImagen extends JPanel{
    
    public PanelImagen(){

    setBackground(Color.DARK_GRAY);
                
     //Etiqueta Imagen
    ImageIcon imagen = new ImageIcon("telefono.png");
    JLabel etiquetaI = new JLabel();
    etiquetaI.setIcon(new ImageIcon(imagen.getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH)));
    add(etiquetaI);
}
}
