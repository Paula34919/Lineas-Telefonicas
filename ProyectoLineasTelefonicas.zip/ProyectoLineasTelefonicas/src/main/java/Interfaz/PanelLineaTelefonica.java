/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import mundo.LineaTelefonica;

/**
 *
 * @author julyj
 */
public class PanelLineaTelefonica extends JPanel implements ActionListener{
    //Atributos
    private static final String AGREGAR = "AGREGAR";
    private InterfazLineasTelefonicas principal;
    private int numeroLinea;
    private JButton btnAgregar;
    
    //Etiquetas
    private JLabel etiquetaLlamadas, etiquetaPrecio, etiquetaMinutos, etiquetaNombre;
    
    public PanelLineaTelefonica(int numeroLineaA, InterfazLineasTelefonicas principalA ){
        
        this.principal = principalA;
        this.numeroLinea = numeroLineaA;
        setLayout( new GridLayout(5,1) );
        setBounds(0, 0, 600, 300);
        setVisible(false);
        
        etiquetaNombre = new JLabel();
        etiquetaNombre.setText("Línea No. " + numeroLinea);
        etiquetaNombre.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaNombre.setOpaque(true); //Establecemos pintar el fondo de la etiqueta
        etiquetaNombre.setBackground(Color.cyan); //Cambiamos el color del fondo de la etiqueta
        add(etiquetaNombre);
        
        //Creación de etiquetas
        
        etiquetaPrecio = new JLabel( formatearValor(0) );
        etiquetaPrecio.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaPrecio.setOpaque(true); //Establecemos pintar el fondo de la etiqueta
        etiquetaPrecio.setBackground(Color.cyan); //Cambiamos el color del fondo de la etiqueta
        add(etiquetaPrecio); 
        
        etiquetaLlamadas = new JLabel();
        etiquetaLlamadas.setText("Numero de Llamadas: " + 0);
        etiquetaLlamadas.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaLlamadas.setOpaque(true); //Establecemos pintar el fondo de la etiqueta
        etiquetaLlamadas.setBackground(Color.cyan); //Cambiamos el color del fondo de la etiqueta
        add(etiquetaLlamadas);                
                
        etiquetaMinutos = new JLabel();
        etiquetaMinutos.setText("Numero de Minutos: " + 0);
        etiquetaMinutos.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaMinutos.setOpaque(true); //Establecemos pintar el fondo de la etiqueta
        etiquetaMinutos.setBackground(Color.cyan); //Cambiamos el color del fondo de la etiqueta
        add(etiquetaMinutos);
        
        btnAgregar = new JButton( "Agregar Llamada" );
        btnAgregar.setPreferredSize( new Dimension( 150, 25 ) );
        btnAgregar.setActionCommand( AGREGAR );
        btnAgregar.addActionListener(this);
        add(btnAgregar);
                
        
    }
    
    public void actualizar(LineaTelefonica linea){
        etiquetaPrecio.setText( formatearValor( linea.darCostoLlamadas( ) ) );
        etiquetaLlamadas.setText( "Número Llamadas: " + formatearValorEntero( linea.darNumeroLlamadas( ) ) );
        etiquetaMinutos.setText( "Número de Minutos: " + formatearValorEntero( linea.darNumeroMinutos( ) ) );
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
           if( AGREGAR.equals( e.getActionCommand( ) ) )
        {
            principal.agregarLlamada( numeroLinea );
        }
    }
    
    String formatearValor(double valor){
        DecimalFormat df = ( DecimalFormat )NumberFormat.getInstance( );
        df.applyPattern( "$ ###,###.##" );
        df.setMinimumFractionDigits( 2 );
        return df.format( valor );
    }
    String formatearValorEntero(int valor) {
        DecimalFormat df = ( DecimalFormat )NumberFormat.getInstance( );
        df.applyPattern( " ###,###" );
        df.setMinimumFractionDigits( 0 );
        return df.format( valor );
    }
    
    public void modoEnteros(LineaTelefonica linea) {
         etiquetaPrecio.setText( formatearValorEntero( (int)linea.darCostoLlamadas( ) ) );
    }
}
        

 
