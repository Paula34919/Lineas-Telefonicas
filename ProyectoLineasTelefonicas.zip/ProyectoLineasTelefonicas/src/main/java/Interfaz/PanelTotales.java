/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import java.awt.Color;
import java.awt.GridLayout;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import mundo.Empresa;

/**
 *
 * @author julyj
 */
public class PanelTotales extends JPanel{
    //Atributos
     private final JLabel etiquetaLlamadasT, etiquetaMinutosT, etiquetaNombreT, etiquetaPrecioT, etiquetaPromedio;

    public PanelTotales(){        
        
        setLayout(new GridLayout(5,1));
        
        //Creacion de etiquetas
        etiquetaNombreT = new JLabel();
        etiquetaNombreT.setText("Totales");
        etiquetaNombreT.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaNombreT.setOpaque(true); //Establecemos pintar el fondo de la etiqueta
        etiquetaNombreT.setBackground(Color.cyan); //Cambiamos el color del fondo de la etiqueta
        add(etiquetaNombreT);
        
        etiquetaPrecioT = new JLabel();
        etiquetaPrecioT.setText("$" + 0);
        etiquetaPrecioT.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaPrecioT.setOpaque(true); //Establecemos pintar el fondo de la etiqueta
        etiquetaPrecioT.setBackground(Color.cyan); //Cambiamos el color del fondo de la etiqueta
        add(etiquetaPrecioT);
        
        etiquetaLlamadasT = new JLabel();
        etiquetaLlamadasT.setText("Llamadas Totales: " + 0);
        etiquetaLlamadasT.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaLlamadasT.setOpaque(true); //Establecemos pintar el fondo de la etiqueta
        etiquetaLlamadasT.setBackground(Color.cyan); //Cambiamos el color del fondo de la etiqueta
        add(etiquetaLlamadasT);  
                
        etiquetaMinutosT = new JLabel();
        etiquetaMinutosT.setText("Minutos Totales: " + 0);
        etiquetaMinutosT.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaMinutosT.setOpaque(true); //Establecemos pintar el fondo de la etiqueta
        etiquetaMinutosT.setBackground(Color.cyan); //Cambiamos el color del fondo de la etiqueta
        add(etiquetaMinutosT);
        
        etiquetaPromedio = new JLabel();
        etiquetaPromedio.setText("Costo promedio por minuto: N/A");
        etiquetaPromedio.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaPromedio.setOpaque(true); //Establecemos pintar el fondo de la etiqueta
        etiquetaPromedio.setBackground(Color.cyan); //Cambiamos el color del fondo de la etiqueta
        add(etiquetaPromedio);
             
    }
    
    public void actualizar(Empresa empresa){
        etiquetaPrecioT.setText( formatearValor( empresa.darTotalCostoLlamadas( ) ) );
        etiquetaLlamadasT.setText( "Llamadas totales: " + formatearValorEntero( empresa.darTotalNumeroLlamadas( ) ) );
        etiquetaMinutosT.setText( "Minutos totales: " + formatearValorEntero( empresa.darTotalMinutos( ) ) );
        if( !Double.isNaN( empresa.darCostoPromedioMinuto( ) ) ) //Entender
        {
            etiquetaPromedio.setText( "Costo promedio por minuto: " + formatearValor( empresa.darCostoPromedioMinuto( ) ) );
        }
        else
        {
            etiquetaPromedio.setText( "Costo promedio por minuto: N/A" );
        }
    }
    String formatearValor(double valor){
        DecimalFormat df = ( DecimalFormat )NumberFormat.getInstance( ); //Entender
        df.applyPattern( "$ ###,###.##" );
        df.setMinimumFractionDigits( 2 );
        return df.format( valor );
    }

    String formatearValorEntero(int valor) {
        DecimalFormat df = ( DecimalFormat )NumberFormat.getInstance( );
        df.applyPattern( " ###,###" );
        df.setMinimumFractionDigits( 0 );
        return df.format( valor );
    }

    public void modoEnteros(Empresa empresa) {
        etiquetaPrecioT.setText( formatearValorEntero((int)empresa.darTotalCostoLlamadas()) );
        if( !Double.isNaN( empresa.darCostoPromedioMinuto( ) ) ) //Entender
        {
            etiquetaPromedio.setText( "Costo promedio por minuto: " + formatearValorEntero( (int)empresa.darCostoPromedioMinuto( ) ) );
        }
        else
        {
            etiquetaPromedio.setText( "Costo promedio por minuto: N/A" );
        }
        
    }
}
