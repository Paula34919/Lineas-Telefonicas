package mundo;
public class LineaTelefonica {
    private int numeroLlamadas;
    private int numeroMinutos;
    private double costoLlamadas;

    public void inicilizar() {
        numeroLlamadas = 0;
        numeroMinutos = 0;
        costoLlamadas = 0.0;
    }

    public void reiniciar() {
        inicilizar();
    }

    public double darCostoLlamadas() {
        return costoLlamadas;
    }

    public int darNumeroLlamadas(){
        return numeroLlamadas;
    }

    public int darNumeroMinutos() {
        return numeroMinutos;
    }

    public void agregarLlamadaLocal(int minutos){
        numeroLlamadas++;
        numeroMinutos += minutos;
        // Supongamos un costo de $0.10 por minuto para llamadas locales
        costoLlamadas += minutos * 0.1;
        //costoLlamadas += (numeroMinutos * 380); 
    }

    public void agregarLlamadaLargaDistancia(int minutos) {
        numeroLlamadas++;
        numeroMinutos += minutos;
        // Supongamos un costo de $0.50 por minuto para llamadas de larga distancia
        costoLlamadas += minutos * 0.5;
        //costoLlamadas += (numeroMinutos * 999);
    }

    public void agregarLlamadaCelular(int minutos) {
        numeroLlamadas++;
        numeroMinutos += minutos;
        // Supongamos un costo de $1.00 por minuto para llamadas a celulares
        costoLlamadas += minutos * 1.0;
        //costoLlamadas += (numeroMinutos * 35);
    }
}
