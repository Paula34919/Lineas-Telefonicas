package test;
import mundo.LineaTelefonica;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import junit.framework.TestCase;

public class LineaTelefonicaTest extends TestCase{
    private LineaTelefonica linea;

    public void setupEscenario1() {
        linea = new LineaTelefonica( );
        linea.inicializar( );
    }
    
    public void testAgregarLlamadaCelular(){
        setupEscenario1( );
        linea.agregarLlamadaCelular( 10 );
        assertEquals( "El número de llamadas debe ser 1", 1, linea.darNumeroLlamadas( ) );
        assertEquals( "El número de minutos debe ser 10", 10, linea.darNumeroMinutos( ) );
        assertEquals( "El costo debe ser $9.990", 9990, linea.darCostoLlamadas( ), 0.001 );
    }

    public void testAgregarLlamadaLocal() {
        setupEscenario1( );
        linea.agregarLlamadaLocal( 5 );
        assertEquals( "El número de llamadas debe ser 1", 1, linea.darNumeroLlamadas( ) );
        assertEquals( "El número de minutos debe ser 5", 5, linea.darNumeroMinutos( ) );
        assertEquals( "El costo debe ser $175", 175, linea.darCostoLlamadas( ), 0.001 );
    }

    public void testAgregarLlamadaLargaDistancia() {
        setupEscenario1( );
        linea.agregarLlamadaLargaDistancia( 7 );
        assertEquals( "El número de llamadas debe ser 1", 1, linea.darNumeroLlamadas( ) );
        assertEquals( "El número de minutos debe ser 5", 7, linea.darNumeroMinutos( ) );
        assertEquals( "El costo debe ser $2.660", 2660, linea.darCostoLlamadas( ), 0.001 );
    }

    public void testReiniciar(){
        setupEscenario1( );
        linea.agregarLlamadaLargaDistancia( 7 );
        linea.reiniciar( );
        assertEquals( "El número de llamadas debe ser 0", 0, linea.darNumeroLlamadas( ) );
        assertEquals( "El número de minutos debe ser 0", 0, linea.darNumeroMinutos( ) );
        assertEquals( "El costo debe ser $0.0", 0, linea.darCostoLlamadas( ), 0.001 );
    }
}
