package test;
import mundo.Empresa;
import junit.framework.TestCase;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class EmpresaTest{
    private Empresa empresa;

    public void setupEscenario1() {
        empresa = new Empresa( );
        empresa.inicializar( );
    }

    public void setupEscenario2() {
        empresa = new Empresa( );
        empresa.inicializar( );

        empresa.agregarLlamadaLocalLinea1( 1 );
        empresa.agregarLlamadaLargaDistanciaLinea1( 2 );
        empresa.agregarLlamadaCelularLinea1( 3 );

        empresa.agregarLlamadaLocalLinea2( 10 );
        empresa.agregarLlamadaLargaDistanciaLinea2( 20 );
        empresa.agregarLlamadaCelularLinea2( 30 );

        empresa.agregarLlamadaLocalLinea2( 100 );
        empresa.agregarLlamadaLargaDistanciaLinea2( 200 );
        empresa.agregarLlamadaCelularLinea2( 300 );
    }

    public void testinicializacion() {
        setupEscenario1( );
        assertNotNull( "La línea telefónica 1 debe estar inicializada", empresa.darLinea1( ) );
        assertNotNull( "La línea telefónica 2 debe estar inicializada", empresa.darLinea2( ) );
        assertNotNull( "La línea telefónica 3 debe estar inicializada", empresa.darLinea3( ) );
    }

    public void testAgregarLlamadaLocalLinea1() {
        setupEscenario1( );
        empresa.agregarLlamadaLocalLinea1( 10 );
        assertEquals( "La llamada no quedó registrada", 1, empresa.darLinea1( ).darNumeroLlamadas( ) );
    }

    public void testAgregarLlamadaLocalLinea2() {
        setupEscenario1( );
        empresa.agregarLlamadaLocalLinea2( 10 );
        assertEquals( "La llamada no quedó registrada", 1, empresa.darLinea2( ).darNumeroLlamadas( ) );
    }

    public void testAgregarLlamadaLocalLinea3() {
        setupEscenario1( );
        empresa.agregarLlamadaLocalLinea3( 10 );
        assertEquals( "La llamada no quedó registrada", 1, empresa.darLinea3( ).darNumeroLlamadas( ) );
    }

    public void testAgregarLlamadaLargaDistanciaLinea1(){
        setupEscenario1( );
        empresa.agregarLlamadaLargaDistanciaLinea1( 10 );
        assertEquals( "La llamada no quedó registrada", 1, empresa.darLinea1( ).darNumeroLlamadas( ) );
    }

    public void testAgregarLlamadaLargaDistanciaLinea2(){
        setupEscenario1( );
        empresa.agregarLlamadaLargaDistanciaLinea2( 10 );
        assertEquals( "La llamada no quedó registrada", 1, empresa.darLinea2( ).darNumeroLlamadas( ) );
    }

    public void testAgregarLlamadaLargaDistanciaLinea3(){
        setupEscenario1( );
        empresa.agregarLlamadaLargaDistanciaLinea3( 10 );
        assertEquals( "La llamada no quedó registrada", 1, empresa.darLinea3( ).darNumeroLlamadas( ) );
    }

    public void testAgregarCelularDistanciaLinea1() {
        setupEscenario1( );
        empresa.agregarLlamadaCelularLinea1( 10 );
        assertEquals( "La llamada no quedó registrada", 1, empresa.darLinea1( ).darNumeroLlamadas( ) );
    }

    public void testAgregarCelularDistanciaLinea2() {
        setupEscenario1( );
        empresa.agregarLlamadaCelularLinea2( 10 );
        assertEquals( "La llamada no quedó registrada", 1, empresa.darLinea2( ).darNumeroLlamadas( ) );
    }

    public void testAgregarCelularDistanciaLinea3() {
        setupEscenario1( );
        empresa.agregarLlamadaCelularLinea3( 10 );
        assertEquals( "La llamada no quedó registrada", 1, empresa.darLinea3( ).darNumeroLlamadas( ) );
    }

    public void testDarTotalLlamadas() {
        setupEscenario2( );
        assertEquals( "El numero de llamadas debe ser 9", 9, empresa.darTotalNumeroLlamadas( ) );
    }
    
    public void testDarTotalMinutos() {
        setupEscenario2( );
        assertEquals( "El total de minutos debe ser 666", 666, empresa.darTotalMinutos( ) );
    }

    public void testDarTotalCosto() {
        setupEscenario2( );
        assertEquals( "El costo es inválido. Debe ser $ 420.912", 420912, empresa.darTotalCostoLlamadas( ), 0.001 );
    }

    public void testDarCostoPromedio() {
        setupEscenario2( );
        assertEquals( "El costo promedio es inválido. Debe ser $632", 632, empresa.darCostoPromedioMinuto( ), 0.001 );
    }

    public void testReiniciar() {
        setupEscenario2( );
        empresa.reiniciar( );
        assertEquals( "El total de llamadas debe ser cero", 0, empresa.darTotalNumeroLlamadas( ) );
        assertEquals( "El total de minutos debe ser cero", 0, empresa.darTotalMinutos( ) );
        assertEquals( "El costo total de llamadas debe ser cero", 0, empresa.darTotalCostoLlamadas( ), 0.01 );
    }
}