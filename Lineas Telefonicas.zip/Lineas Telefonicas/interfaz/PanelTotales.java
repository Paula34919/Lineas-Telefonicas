package interfaz;
import mundo.Empresa;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class PanelTotales extends JPanel{
    private JLabel etiquetaCosto;
    private JLabel etiquetaNumeroLlamadas;
    private JLabel etiquetaMinutos;
    private JLabel etiquetaCostoPromedio;

    PanelTotales() {
        setBorder( new TitledBorder( "Totales" ) );
        setLayout( new GridBagLayout( ) );

        //
        //Etiqueta Costo
        etiquetaCosto = new JLabel( formatearValor( 0 ) );
        etiquetaCosto.setForeground( Color.BLUE.darker( ) );
        etiquetaCosto.setFont( new Font( "Tahoma", Font.BOLD, 48 ) );

        //
        //Etiqueta Numero de llamadas
        etiquetaNumeroLlamadas = new JLabel( "Total Llamadas: 0" );

        //Etiqueta Total de Minutos
        etiquetaMinutos = new JLabel( "Total Minutos: 0" );

        //Etiqueta costo promedio por minuto
        etiquetaCostoPromedio = new JLabel( "Costo promedio por minuto: N/A" );

        //Organización
        GridBagConstraints posicion = new GridBagConstraints( 2, 2, 1, 15, 1, 15, GridBagConstraints.CENTER, GridBagConstraints.VERTICAL, new Insets( 5, 5, 5, 5 ), 0, 0 );
        add( etiquetaCosto, posicion );

        posicion = new GridBagConstraints( 2, 17, 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets( 5, 5, 5, 5 ), 0, 0 );
        add( etiquetaNumeroLlamadas, posicion );

        posicion = new GridBagConstraints( 2, 18, 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets( 5, 5, 5, 5 ), 0, 0 );
        add( etiquetaMinutos, posicion );

        posicion = new GridBagConstraints( 2, 19, 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets( 5, 5, 5, 5 ), 0, 0 );
        add( etiquetaCostoPromedio, posicion );
    }
    public void actualizar(Empresa empresa){
        etiquetaCosto.setText( formatearValor( empresa.darTotalCostoLlamadas( ) ) );
        etiquetaNumeroLlamadas.setText( "Total Llamadas: " + formatearValorEntero( empresa.darTotalNumeroLlamadas( ) ) );
        etiquetaMinutos.setText( "Total de Minutos: " + formatearValorEntero( empresa.darTotalMinutos( ) ) );
        if( !Double.isNaN( empresa.darCostoPromedioMinuto( ) ) )
        {
            etiquetaCostoPromedio.setText( "Costo promedio por minuto: " + formatearValor( empresa.darCostoPromedioMinuto( ) ) );
        }
        else
        {
            etiquetaCostoPromedio.setText( "Costo promedio por minuto: N/A" );
        }
    }
    String formatearValor(double valor){
        DecimalFormat df = ( DecimalFormat )NumberFormat.getInstance( );
        df.applyPattern( "$ ###,###.##" );
        df.setMinimumFractionDigits( 2 );
        return df.format( valor );
    }

    String formatearValorEntero(int valor) {
        DecimalFormat df = ( DecimalFormat )NumberFormat.getInstance( );
        df.applyPattern( " ###,###" );
        df.setMinimumFractionDigits( 0 );
        return df.format( valor );
    }
 }
