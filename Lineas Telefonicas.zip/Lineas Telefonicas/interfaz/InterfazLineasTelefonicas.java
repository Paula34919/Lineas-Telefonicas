package interfaz;
import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import mundo.Empresa;

public class InterfazLineasTelefonicas {
    private Empresa empresa;
    private PanelImagen panelImagen;
    private PanelTotales panelTotales;
    private PanelLineaTelefonica panelLinea1;
    private PanelLineaTelefonica panelLinea2;
    private PanelLineaTelefonica panelLinea3;
    private PanelExtension panelExtension;

    public InterfazLineasTelefonicas( )
    {
        // Crea la clase principal
        empresa = new Empresa( );
        empresa.inicializar( );

        // Construye la forma
        // organizar el panel principal
        getContentPane( ).setLayout( new BorderLayout( ) );
        //setSize( 530, 530 );
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        setTitle( "MiEmpresa - Manejo Líneas Telefónicas" );

        //Creación de los paneles aquí
        JPanel panelSuperior = new JPanel( );
        panelSuperior.setLayout( new BorderLayout( ) );
        getContentPane( ).add( panelSuperior, BorderLayout.NORTH );

        panelImagen = new PanelImagen( );
        panelSuperior.add( panelImagen, BorderLayout.WEST );

        panelTotales = new PanelTotales( );
        panelSuperior.add( panelTotales, BorderLayout.CENTER );

        JPanel panelContenedor = new JPanel( );
        panelContenedor.setLayout( new GridLayout( 1, 3 ) );
        getContentPane( ).add( panelContenedor, BorderLayout.CENTER );

        //Agrega los paneles al panel contenedor
        panelLinea1 = new PanelLineaTelefonica( this, 1 );
        panelContenedor.add( panelLinea1 );
        panelLinea2 = new PanelLineaTelefonica( this, 2 );
        panelContenedor.add( panelLinea2 );
        panelLinea3 = new PanelLineaTelefonica( this, 3 );
        panelContenedor.add( panelLinea3 );

        //Panel extensiones
        panelExtension = new PanelExtension( this );
        getContentPane( ).add( panelExtension, BorderLayout.SOUTH );

        pack( );
        setResizable( false );
    }

    public void agregarLlamada( int numeroLinea )
    {
        //
        //Pregunta el numero de minutos
        String minutos = JOptionPane.showInputDialog( this, "Número de Minutos hablados:" );
        try
        {
            if( minutos != null )
            {
                int min = Integer.parseInt( minutos );
                if( min <= 0 )
                {
                    JOptionPane.showMessageDialog( this, "El número de minutos debe ser mayor a cero", "Error", JOptionPane.ERROR_MESSAGE );
                    return;
                }
                Object[] possibilities = { "Local", "Larga distancia", "Celular" };
                String tipo = ( String )JOptionPane.showInputDialog( this, "Tipo de llamada:", "Tipo", JOptionPane.QUESTION_MESSAGE, null, possibilities, "Local" );
                if( tipo != null )
                {
                    if( numeroLinea == 1 )
                    {
                        if( "Local".equals( tipo ) )
                        {
                            empresa.agregarLlamadaLocalLinea1( min );
                        }
                        else if( "Larga distancia".equals( tipo ) )
                        {
                            empresa.agregarLlamadaLargaDistanciaLinea1( min );
                        }
                        else if( "Celular".equals( tipo ) )
                        {
                            empresa.agregarLlamadaCelularLinea1( min );
                        }
                    }
                    else if( numeroLinea == 2 )
                    {
                        if( "Local".equals( tipo ) )
                        {
                            empresa.agregarLlamadaLocalLinea2( min );
                        }
                        else if( "Larga distancia".equals( tipo ) )
                        {
                            empresa.agregarLlamadaLargaDistanciaLinea2( min );
                        }
                        else if( "Celular".equals( tipo ) )
                        {
                            empresa.agregarLlamadaCelularLinea2( min );
                        }
                    }
                    else if( numeroLinea == 3 )
                    {
                        if( "Local".equals( tipo ) )
                        {
                            empresa.agregarLlamadaLocalLinea3( min );
                        }
                        else if( "Larga distancia".equals( tipo ) )
                        {
                            empresa.agregarLlamadaLargaDistanciaLinea3( min );
                        }
                        else if( "Celular".equals( tipo ) )
                        {
                            empresa.agregarLlamadaCelularLinea3( min );
                        }
                    }
                    actualizar( );
                }
            }
        }
        catch( NumberFormatException e )
        {
            JOptionPane.showMessageDialog( this, "El número de minutos es inválido", "Error", JOptionPane.ERROR_MESSAGE );
        }
    }
    public void reiniciar() {
        empresa.reiniciar( );
        actualizar( );
    }

    public void actualizar() {
        panelTotales.actualizar( empresa );
        panelLinea1.actualizar( empresa.darLinea1( ) );
        panelLinea2.actualizar( empresa.darLinea2( ) );
        panelLinea3.actualizar( empresa.darLinea3( ) );
    }

    public void main(String[] args) {
        InterfazLineasTelefonicas interfaz = new InterfazLineasTelefonicas( );
        interfaz.setVisible( true );
    }
}
