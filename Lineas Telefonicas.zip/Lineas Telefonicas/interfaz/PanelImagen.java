package interfaz;
import java.awt.GridBagLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class PanelImagen extends JPanel{

    private JLabel etiquetaImagen;

    public PanelImagen(){
        setBorder( new TitledBorder( "Manejo Líneas Telefónicas" ) );
        setLayout( new GridBagLayout( ) );

        //Etiqueta Logo de la empresa
        ImageIcon icono = new ImageIcon( "data/logo.jpg" );
        etiquetaImagen = new JLabel( "" );
        etiquetaImagen.setIcon( icono );

        add( etiquetaImagen );
    }
}
