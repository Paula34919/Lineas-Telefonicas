import unittest
class EmpresaTest(unittest.TestCase):
    def setupEscenario1(self):
        # Configurar el escenario de prueba con llamadas locales
        self.llamada_local_1 = "+5712345678"  # Ejemplo de número de teléfono local
        self.llamada_local_2 = "+5719876543"  # Ejemplo de número de teléfono local
        self.llamada_local_3 = "+5714567890"  # Ejemplo de número de teléfono local

        # Verificar que las llamadas locales sean correctas
        self.assertTrue(self.llamada_local_1.startswith("+57"))
        self.assertTrue(self.llamada_local_2.startswith("+57"))
        self.assertTrue(self.llamada_local_3.startswith("+57"))

    def setupEscenario2(self):
        # Configurar el escenario de prueba con llamadas a distancia
        self.llamada_distancia_1 = "+512071234567"  # Ejemplo de número de teléfono de larga distancia
        self.llamada_distancia_2 = "+51987654321"  # Ejemplo de número de teléfono de larga distancia
        self.llamada_distancia_3 = "+51123456789"  # Ejemplo de número de teléfono de larga distancia

        # Verificar que las llamadas a distancia sean correctas
        self.assertEqual(self.llamada_distancia_1.startswith("+51"))
        self.assertEqual(self.llamada_distancia_2.startswith("+51"))
        self.assertEqual(self.llamada_distancia_3.startswith("+51"))

    def testAgregarLlamadaLocalLinea1(self):
        self.setupEscenario1()  # Llamar al escenario 1

        # Hacer algo relacionado con agregar la llamada local a la línea 1
        # Ejemplo: Agregar la llamada local 1 a la línea 1
        self.agregarLlamadaLocalALinea1(self.llamada_local_1)

        # Verificar que la llamada local 1 esté presente en la línea 1
        self.assertIn(self.llamada_local_1, "Llamadas de línea 1")

    def testAgregarLlamadaLocalLinea2(self):
        self.setupEscenario1()  # Llamar al escenario 1

        # Hacer algo relacionado con agregar la llamada local a la línea 2
        # Ejemplo: Agregar la llamada local 2 a la línea 2
        self.agregarLlamadaLocalALinea2(self.llamada_local_2)

        # Verificar que la llamada local 2 esté presente en la línea 2
        self.assertIn(self.llamada_local_2, "Llamadas de línea 2")

    def testAgregarLlamadaLocalLinea3(self):
        self.setupEscenario1()  # Llamar al escenario 1

        # Hacer algo relacionado con agregar la llamada local a la línea 3
        # Ejemplo: Agregar la llamada local 3 a la línea 3
        self.agregarLlamadaLocalALinea3(self.llamada_local_3)

        # Verificar que la llamada local 3 esté presente en la línea 3
        self.assertIn(self.llamada_local_3, "Llamadas de línea 3")

    def testAgregarLlamadaLargaDistanciaLinea1(self):
        self.setupEscenario2()  # Llamar al escenario 2

        # Hacer algo relacionado con agregar la llamada a distancia a la línea 1
        # Ejemplo: Agregar la llamada a distancia 1 a la línea 1
        self.agregarLlamadaDistanciaALinea1(self.llamada_distancia_1)

        # Verificar que la llamada a distancia 1 esté presente en la línea 1
        self.assertIn(self.llamada_distancia_1, "Llamadas de línea 1")

    def testAgregarLlamadaLargaDistanciaLinea2(self):
        self.setupEscenario2()  # Llamar al escenario 2

        # Hacer algo relacionado con agregar la llamada a distancia a la línea 2
        # Ejemplo: Agregar la llamada a distancia 2 a la línea 2
        self.agregarLlamadaDistanciaALinea2(self.llamada_distancia_2)

    def testAgregarLlamadaLargaDistanciaLinea3(self):
        self.setupEscenario2()  # Llamar al escenario 2

        # Hacer algo relacionado con agregar la llamada a distancia a la línea 3
        # Ejemplo: Agregar la llamada a distancia 3 a la línea 3
        self.agregarLlamadaDistanciaALinea3(self.llamada_distancia_3)

        # Verificar que la llamada a distancia 3 esté presente en la línea 3
        self.assertIn(self.llamada_distancia_3, "Llamadas de línea 3")

    def testAgregarCelularDistanciaLinea1(self):
        self.setupEscenario2()  # Llamar al escenario 2

        # Hacer algo relacionado con agregar el celular de larga distancia a la línea 1
        # Ejemplo: Agregar el celular 1 de larga distancia a la línea 1
        self.agregarCelularDistanciaALinea1(self.celular_distancia_1)

        # Verificar que el celular de larga distancia 1 esté presente en la línea 1
        self.assertIn(self.celular_distancia_1, "Celulares de línea 1")

    def testAgregarCelularDistanciaLinea2(self):
        self.setupEscenario2()  # Llamar al escenario 2

        # Hacer algo relacionado con agregar el celular de larga distancia a la línea 2
        # Ejemplo: Agregar el celular 2 de larga distancia a la línea 2
        self.agregarCelularDistanciaALinea2(self.celular_distancia_2)

        # Verificar que el celular de larga distancia 2 esté presente en la línea 2
        self.assertIn(self.celular_distancia_2, "Celulares de línea 2")
    
    def testAgregarCelularDistanciaLinea3(self):
        self.setupEscenario2()  # Llamar al escenario 2

        # Hacer algo relacionado con agregar el celular de larga distancia a la línea 3
        # Ejemplo: Agregar el celular 3 de larga distancia a la línea 3
        self.agregarCelularDistanciaALinea3(self.celular_distancia_3)

        # Verificar que el celular de larga distancia 3 esté presente en la línea 3
        self.assertIn(self.celular_distancia_3, "Celulares de línea 3")
#////////////////////////////////////////////////////////////////////////////////////////////////////////////
    def testDarTotalLlamadas(self):
        self.setupEscenario1()  # Llamar al escenario 1

        # Hacer algo relacionado con obtener el total de llamadas realizadas
        total_llamadas = self.llamadas

        # Verificar que el total de llamadas sea el esperado
        self.assertEqual(total_llamadas, 3)  # Reemplaza 3 con el valor esperado de llamadas realizadas
        
    def testDarTotalMinutos(self):
        self.setupEscenario1()  # Llamar al escenario 1

        # Hacer algo relacionado con obtener el total de minutos transcurridos en las llamadas
        total_minutos = self.obtenerTotalMinutos()

        # Verificar que el total de minutos sea el esperado
        self.assertEqual(total_minutos, 60)  # Reemplaza 60 con el valor esperado de minutos transcurridos

    def testDarTotalCosto(self):
        self.setupEscenario1()  # Llamar al escenario 1

        # Hacer algo relacionado con obtener el costo total de todas las llamadas
        costo_total = self.obtenerCostoTotal()

        # Calcular el costo esperado considerando el costo de las llamadas locales y a distancia
        costo_esperado = 0
        for llamada in self.llamadas:
            minutos = llamada.obtenerMinutos()  # Reemplaza 'obtenerMinutos()' con el método real de tu implementación
            if llamada.esLocal():
                costo_esperado += minutos * 200  # Costo por minuto para llamadas locales: 200 pesos
            else:
                costo_esperado += minutos * 500  # Costo por minuto para llamadas a distancia: 500 pesos

        # Verificar que el costo total sea el esperado
        self.assertEqual(costo_total, costo_esperado)

    def testDarCostoPromedio(self):
        self.setupEscenario1()  # Llamar al escenario 1

        # Obtener la cantidad total de llamadas realizadas
        total_llamadas = self.testDarTotalLlamadas()

        # Obtener el total de minutos transcurridos en todas las llamadas
        total_minutos = self.testDarTotalMinutos()

        # Obtener el costo total de todas las llamadas
        costo_total = self.testDarTotalCosto()

        # Calcular el costo promedio
        costo_promedio = costo_total / total_llamadas

        # Verificar que el costo promedio sea el esperado
        self.assertEqual(costo_promedio, 75)  # Reemplaza 75 con el valor esperado del costo promedio

    def testReiniciar(self):
        self.setUp()
        self.llamadas =+ 1

if __name__ == '__main__':
    unittest.main()
